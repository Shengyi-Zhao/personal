'''
test every algorithm
'''
from io import StringIO
import numpy
import openpyxl
import xgboost
from keras.preprocessing import text
from keras_preprocessing import sequence

from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from sklearn import metrics, svm, ensemble, decomposition
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import pandas, string, more_data
import os
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer



def convert_pdf_2_text(path):

    rsrcmgr = PDFResourceManager()
    retstr = StringIO()

    device = TextConverter(rsrcmgr, retstr, laparams=LAParams())
    interpreter = PDFPageInterpreter(rsrcmgr, device)

    with open(path, 'rb') as fp:
        for page in PDFPage.get_pages(fp, set()):
            interpreter.process_page(page)
        text = retstr.getvalue()

    device.close()
    retstr.close()

    return text


import re
new_text1=convert_pdf_2_text('climate-change-wr.pdf')
pattern = r'\.'
result_list = re.split(pattern, new_text1)
result_list2=[]
f = open("new 1.txt",'rb')
line = f.readline()
while line:
    s=str(line, encoding="utf-8")
    result_list2.append(s)
    line = f.readline()
f.close()
result_list3=[]
f2=open('News_Category_Dataset_v2.json', 'r', encoding="utf-8")
    # 读取所有行 每行会是一个字符串
for str in f2.readlines():
    # 将josn字符串转化为dict字典
    j = more_data.loads(str)
    t = j["headline"]+j["short_description"]
    result_list3.append(t)
f2.close()
result_list4=[]
new_text5=convert_pdf_2_text('new 5.pdf')
pattern2 = r'\...'
result_list5 = re.split(pattern2, new_text5)
new_text6=convert_pdf_2_text('new 6.pdf')
result_list6 = re.split(pattern2, new_text6)

workbook=openpyxl.load_workbook("naturalnews.xlsx")
worksheet=workbook.get_sheet_by_name("data")
name=worksheet.title
columns=worksheet.max_column
for row in worksheet.rows:
    text4=row[0].value+row[1].value
    result_list4.append(text4)


stop = set(stopwords.words('english'))
exclude = set(string.punctuation)
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized


def get_tweet_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    i=0
    while i <(len(result_list)-2):
        text1=result_list[i]
        text2 =result_list[i+1]
        text3 =result_list[i+2]
        new_data_after_clean = clean(text1)+clean(text2)+clean(text3)
        texts.append(new_data_after_clean)
        labels.append(0)
        i=i+3
    i=0
    while i <(len(result_list2)-4):
        text1=result_list2[i]
        text2=result_list2[i+1]
        text3=result_list2[i+2]
        text4=result_list2[i+3]
        text5=result_list2[i+4]
        new_data2=text1+text2+text3+text4+text5
        new_data_after_clean2 = clean(new_data2)
        texts.append(new_data_after_clean2)
        labels.append(0)
        i=i+5
    while i <(len(result_list3)-7):
        text1=result_list3[i]
        text2=result_list3[i+1]
        text3=result_list3[i+2]
        text4=result_list3[i+3]
        text5=result_list3[i+4]
        text6 = result_list3[i + 5]
        text7 = result_list3[i + 6]
        text8 = result_list3[i + 7]
        new_data3=text1+text2+text3+text4+text5+text6+text7+text8
        new_data_after_clean3 = clean(new_data3)
        texts.append(new_data_after_clean3)
        labels.append(0)
        i=i+8
    for t in result_list4:
        texts.append(t)
        labels.append(1)
    for aa in result_list5:
        texts.append(aa)
        labels.append(0)
    for aaa in result_list6:
        texts.append(aaa)
        labels.append(0)
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
def get_deve_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
trainDF=get_tweet_from_json("train.json")
devDF=get_deve_from_json("dev.json")
train_x=trainDF['text']
train_y=trainDF['label']
valid_x=devDF['text']
valid_y=devDF['label']

#创建一个向量计数器对象
count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
count_vect.fit(trainDF['text'])

#使用向量计数器对象转换训练集和验证集
xtrain_count = count_vect.transform(train_x)
xvalid_count = count_vect.transform(valid_x)
# ngram 级tf-idf
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram = tfidf_vect_ngram.transform(train_x)
xvalid_tfidf_ngram = tfidf_vect_ngram.transform(valid_x)


lda_model = decomposition.LatentDirichletAllocation(n_components=20, learning_method='online', max_iter=20)
X_topics = lda_model.fit_transform(xtrain_count)
v_topics=lda_model.transform(xvalid_count)

def train_model(classifier, feature_vector_train, label, feature_vector_valid, is_neural_net=False):
    # fit the training dataset on the classifier
    classifier.fit(feature_vector_train, label)

    # predict the labels on validation dataset
    predictions = classifier.predict(feature_vector_valid)

    if is_neural_net:
        predictions = predictions.argmax(axis=-1)
    j=0
    for i in range(len(predictions)):
        if valid_y[i] != predictions[i]:
            print(valid_x[i])
            print(valid_y[i])
            print(predictions[i])
            j=j+1
            print(j)
            print('----------')
    print(j)
    print(len(predictions))

    return metrics.f1_score(predictions, valid_y)



    return model
#加载预先训练好的词嵌入向量
embeddings_index = {}
for i, line in enumerate(open('E:\wiki-news-300d-1M.vec',encoding='utf-8')):
    values = line.split()
    embeddings_index[values[0]] = numpy.asarray(values[1:], dtype='float32')


#创建一个分词器
token = text.Tokenizer()
token.fit_on_texts(trainDF['text'])
word_index = token.word_index

#将文本转换为分词序列，并填充它们保证得到相同长度的向量
train_seq_x = sequence.pad_sequences(token.texts_to_sequences(train_x), maxlen=70)
valid_seq_x = sequence.pad_sequences(token.texts_to_sequences(valid_x), maxlen=70)

#创建分词嵌入映射
embedding_matrix = numpy.zeros((len(word_index) + 1, 300))
for word, i in word_index.items():
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None:
        embedding_matrix[i] = embedding_vector



accuracy3 = train_model(ensemble.RandomForestClassifier(), xtrain_tfidf_ngram, train_y, xvalid_tfidf_ngram)
accuracy2 = train_model(xgboost.XGBClassifier(), xtrain_tfidf_ngram.tocsc(), train_y, xvalid_tfidf_ngram.tocsc())
accuracy = train_model(svm.SVC(),xtrain_tfidf_ngram, train_y, xvalid_tfidf_ngram)
print("SVM, N-Gram Vectors: ", accuracy)
print("Xgb, CharLevel Vectors: ", accuracy2)
print("forest", accuracy3)


