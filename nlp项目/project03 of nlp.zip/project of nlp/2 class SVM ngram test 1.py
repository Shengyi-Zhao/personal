'''
get output for testing model
'''
from io import StringIO

import numpy
import openpyxl
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from sklearn import metrics, svm, ensemble, linear_model, naive_bayes
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import pandas, string, more_data
import os
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.metrics import roc_curve


def convert_pdf_2_text(path):

    rsrcmgr = PDFResourceManager()
    retstr = StringIO()

    device = TextConverter(rsrcmgr, retstr, laparams=LAParams())
    interpreter = PDFPageInterpreter(rsrcmgr, device)

    with open(path, 'rb') as fp:
        for page in PDFPage.get_pages(fp, set()):
            interpreter.process_page(page)
        text = retstr.getvalue()

    device.close()
    retstr.close()

    return text


import re
new_text1=convert_pdf_2_text('climate-change-wr.pdf')
pattern = r'\.'
result_list = re.split(pattern, new_text1)
result_list2=[]
f = open("new 1.txt",'rb')
line = f.readline()
while line:
    s=str(line, encoding="utf-8")
    result_list2.append(s)
    line = f.readline()
f.close()
result_list3=[]
f2=open('News_Category_Dataset_v2.json', 'r', encoding="utf-8")
    # 读取所有行 每行会是一个字符串
for str in f2.readlines():
    # 将josn字符串转化为dict字典
    j = more_data.loads(str)
    t = j["headline"]+j["short_description"]
    result_list3.append(t)
f2.close()
result_list4=[]
new_text5=convert_pdf_2_text('new 5.pdf')
pattern2 = r'\...'
result_list5 = re.split(pattern2, new_text5)
new_text6=convert_pdf_2_text('new 6.pdf')
result_list6 = re.split(pattern2, new_text6)

workbook=openpyxl.load_workbook("naturalnews.xlsx")
worksheet=workbook.get_sheet_by_name("data")
name=worksheet.title
columns=worksheet.max_column
for row in worksheet.rows:
    text4=row[0].value+row[1].value
    result_list4.append(text4)


stop = set(stopwords.words('english'))
exclude = set(string.punctuation)
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized


def get_tweet_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    i=0
    while i <(len(result_list)-2):
        text1=result_list[i]
        text2 =result_list[i+1]
        text3 =result_list[i+2]
        new_data_after_clean = clean(text1)+clean(text2)+clean(text3)
        texts.append(new_data_after_clean)
        labels.append(0)
        i=i+3
    i=0
    while i <(len(result_list2)-4):
        text1=result_list2[i]
        text2=result_list2[i+1]
        text3=result_list2[i+2]
        text4=result_list2[i+3]
        text5=result_list2[i+4]
        new_data2=text1+text2+text3+text4+text5
        new_data_after_clean2 = clean(new_data2)
        texts.append(new_data_after_clean2)
        labels.append(0)
        i=i+5
    while i <(len(result_list3)-7):
        text1=result_list3[i]
        text2=result_list3[i+1]
        text3=result_list3[i+2]
        text4=result_list3[i+3]
        text5=result_list3[i+4]
        text6 = result_list3[i + 5]
        text7 = result_list3[i + 6]
        text8 = result_list3[i + 7]
        new_data3=text1+text2+text3+text4+text5+text6+text7+text8
        new_data_after_clean3 = clean(new_data3)
        texts.append(new_data_after_clean3)
        labels.append(0)
        i=i+8
    for t in result_list4:
        texts.append(t)
        labels.append(1)
    for aa in result_list5:
        texts.append(aa)
        labels.append(0)
    for aaa in result_list6:
        texts.append(aaa)
        labels.append(0)
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
def get_test(file_name):
    texts = []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean=clean(infor['text'])
        texts.append(text_afterclean)
    DF = pandas.DataFrame()
    DF['text'] = texts
    return DF
trainDF = get_tweet_from_json("train.json")
testDF=get_test("test-unlabelled.json")
train_x = trainDF['text']
train_y = trainDF['label']
test_x=testDF['text']

# 创建一个向量计数器对象
count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
count_vect.fit(trainDF['text'])

# 使用向量计数器对象转换训练集和验证集
xtrain_count = count_vect.transform(train_x)
xtest_count = count_vect.transform(test_x)
# ngram 级tf-idf
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2, 3), max_features=5000)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram = tfidf_vect_ngram.transform(train_x)
xtest_tfidf_ngram = tfidf_vect_ngram.transform(test_x)

clf = ensemble.RandomForestClassifier(min_samples_leaf=1, max_depth=190, n_estimators=30,
                                          min_samples_split=2,
                                          class_weight={1: 1, 0: 3})
clf.fit(xtrain_tfidf_ngram,train_y)
y_pred_test = clf.predict(xtest_tfidf_ngram)
for index in range(len(y_pred_test)):
    if y_pred_test[index]==-1:
        y_pred_test[index]=0



json_path = 'test-unlabelled.json'
dict = {}

def get_json_data(json_path):
    # 获取json里面数据

    with open(json_path, 'rb') as f:
        params = more_data.load(f)
        i=0
        for key in params:
            dict_label={"label":y_pred_test[i]}
            params[key] = dict_label
            i += 1
        dict = params
    f.close()
    return dict

class NumpyEncoder(more_data.JSONEncoder):
    """ Special json encoder for numpy types """
    def default(self, obj):
        if isinstance(obj, (numpy.int_, numpy.intc, numpy.intp, numpy.int8,
                            numpy.int16, numpy.int32, numpy.int64, numpy.uint8,
                            numpy.uint16, numpy.uint32, numpy.uint64)):
            return int(obj)
        elif isinstance(obj, (numpy.float_, numpy.float16, numpy.float32,
                              numpy.float64)):
            return float(obj)
        elif isinstance(obj, (numpy.ndarray,)):
            return obj.tolist()
        return more_data.JSONEncoder.default(self, obj)

def write_json_data(dict):
    json_str = more_data.dumps(dict, cls=NumpyEncoder)
    with open('test-output24.json', 'w') as json_file:
         json_file.write(json_str)


the_revised_dict = get_json_data(json_path)
write_json_data(the_revised_dict)

