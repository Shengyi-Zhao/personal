'''
get output of one class svm
'''
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
import pandas, xgboost, numpy, textblob, string, more_data

from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import string
import os
stop = set(stopwords.words('english'))
exclude = set(string.punctuation)
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized

def get_tweet_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean=clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF

def get_test(file_name):
    texts = []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean=clean(infor['text'])
        texts.append(text_afterclean)
    DF = pandas.DataFrame()
    DF['text'] = texts
    return DF
trainDF = get_tweet_from_json("train.json")
testDF=get_test("test-unlabelled.json")
train_x = trainDF['text']
train_y = trainDF['label']
test_x=testDF['text']

# 创建一个向量计数器对象
count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
count_vect.fit(trainDF['text'])

# 使用向量计数器对象转换训练集和验证集
xtrain_count = count_vect.transform(train_x)
xtest_count = count_vect.transform(test_x)
# ngram 级tf-idf
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2, 3), max_features=5000)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram = tfidf_vect_ngram.transform(train_x)
xtest_tfidf_ngram = tfidf_vect_ngram.transform(test_x)


clf = svm.OneClassSVM(kernel='rbf', degree=3, gamma='scale', coef0=0.0, tol=0.001, nu=0.5, shrinking=True, cache_size=200, verbose=False, max_iter=-1)
clf.fit(xtrain_tfidf_ngram)
y_pred_test = clf.predict(xtest_tfidf_ngram)
for index in range(len(y_pred_test)):
    if y_pred_test[index]==-1:
        y_pred_test[index]=0



json_path = 'test-unlabelled.json'
json_path1 = 'test-output.json'
dict = {}

def get_json_data(json_path):
    # 获取json里面数据

    with open(json_path, 'rb') as f:
        params = more_data.load(f)
        i=0
        for key in params:
            dict_label={"label":y_pred_test[i]}
            params[key] = dict_label
            i += 1
        dict = params
    f.close()
    return dict

class NumpyEncoder(more_data.JSONEncoder):
    """ Special json encoder for numpy types """
    def default(self, obj):
        if isinstance(obj, (numpy.int_, numpy.intc, numpy.intp, numpy.int8,
                            numpy.int16, numpy.int32, numpy.int64, numpy.uint8,
                            numpy.uint16, numpy.uint32, numpy.uint64)):
            return int(obj)
        elif isinstance(obj, (numpy.float_, numpy.float16, numpy.float32,
                              numpy.float64)):
            return float(obj)
        elif isinstance(obj, (numpy.ndarray,)):
            return obj.tolist()
        return more_data.JSONEncoder.default(self, obj)

def write_json_data(dict):
    json_str = more_data.dumps(dict, cls=NumpyEncoder)
    with open('test-output.json', 'w') as json_file:
         json_file.write(json_str)


the_revised_dict = get_json_data(json_path)
write_json_data(the_revised_dict)
