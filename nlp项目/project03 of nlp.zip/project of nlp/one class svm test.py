'''
parameter adjustment of one class svm
'''
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
import pandas, xgboost, numpy, textblob, string, more_data

from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import string
import os
stop = set(stopwords.words('english'))
exclude = set(string.punctuation)
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized

def get_tweet_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean=clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF

def get_test(file_name):
    texts = []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean=clean(infor['text'])
        texts.append(text_afterclean)
    DF = pandas.DataFrame()
    DF['text'] = texts
    return DF
trainDF = get_tweet_from_json("train.json")
vaildDF = get_tweet_from_json("dev.json")
train_x = trainDF['text']
train_y = trainDF['label']
vaild_x=vaildDF['text']
vaild_y=vaildDF['label']


# 创建一个向量计数器对象
count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
count_vect.fit(trainDF['text'])

# 使用向量计数器对象转换训练集和验证集
xtrain_count = count_vect.transform(train_x)
xvaild_count = count_vect.transform(vaild_x)
# ngram 级tf-idf
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2, 3), max_features=5000)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram = tfidf_vect_ngram.transform(train_x)
xvaild_tfidf_ngram = tfidf_vect_ngram.transform(vaild_x)

clf1 = svm.OneClassSVM(kernel='linear')
clf1.fit(xtrain_tfidf_ngram)
y_pred_test1 = clf1.predict(xvaild_tfidf_ngram)
for index in range(len(y_pred_test1)):
    if y_pred_test1[index] == -1:
        y_pred_test1[index] = 0
predictions1 = clf1.predict(xvaild_tfidf_ngram)
print(metrics.accuracy_score(predictions1, vaild_y))
for g in [0.001,0.1,0.2,0.3]:
    clf2 = svm.OneClassSVM(nu=0.1, kernel='rbf', gamma=g)
    clf2.fit(xtrain_tfidf_ngram)
    y_pred_test2 = clf2.predict(xvaild_tfidf_ngram)
    for index in range(len(y_pred_test2)):
        if y_pred_test2[index] == -1:
            y_pred_test2[index] = 0
    predictions2 = clf2.predict(xvaild_tfidf_ngram)
    print(metrics.f1_score(predictions2, vaild_y))




