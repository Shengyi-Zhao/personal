
from io import StringIO
from nltk.corpus import stopwords
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage

import pandas, string, json
import os
from nltk import WordNetLemmatizer


def convert_pdf_2_text(path):

    rsrcmgr = PDFResourceManager()
    retstr = StringIO()

    device = TextConverter(rsrcmgr, retstr, laparams=LAParams())
    interpreter = PDFPageInterpreter(rsrcmgr, device)

    with open(path,'rb') as fp:
        for page in PDFPage.get_pages(fp, set()):
            interpreter.process_page(page)
        text = retstr.getvalue()

    device.close()
    retstr.close()

    return text


import re

new_text1=convert_pdf_2_text('climate-change-wr.pdf')
pattern = r'\.'
result_list = re.split(pattern, new_text1)
result_list2=[]
f = open("new 1.txt",'rb')
line = f.readline()
while line:
    s=str(line, encoding="utf-8")
    result_list2.append(s)
    line = f.readline()
f.close()
result_list3=[]
f2=open('News_Category_Dataset_v2.json', 'r', encoding="utf-8")
    # 读取所有行 每行会是一个字符串
for str in f2.readlines():
    # 将josn字符串转化为dict字典
    j = json.loads(str)
    t = j["headline"]+j["short_description"]
    result_list3.append(t)
f2.close()

stop = set(stopwords.words('english'))
exclude = set(string.punctuation)
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized


def get_tweet_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = json.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    i=0
    while i <(len(result_list)-2):
        text1=result_list[i]
        text2 =result_list[i+1]
        text3 =result_list[i+2]
        new_data_after_clean = clean(text1)+clean(text2)+clean(text3)
        texts.append(new_data_after_clean)
        labels.append(0)
        i=i+3
    i=0
    while i <(len(result_list2)-4):
        text1=result_list2[i]
        text2=result_list2[i+1]
        text3=result_list2[i+2]
        text4=result_list2[i+3]
        text5=result_list2[i+4]
        new_data2=text1+text2+text3+text4+text5
        new_data_after_clean2 = clean(new_data2)
        texts.append(new_data_after_clean2)
        labels.append(0)
        i=i+5
    while i <(len(result_list3)-7):
        text1=result_list3[i]
        text2=result_list3[i+1]
        text3=result_list3[i+2]
        text4=result_list3[i+3]
        text5=result_list3[i+4]
        text6 = result_list3[i + 5]
        text7 = result_list3[i + 6]
        text8 = result_list3[i + 7]
        new_data3=text1+text2+text3+text4+text5+text6+text7+text8
        new_data_after_clean3 = clean(new_data3)
        texts.append(new_data_after_clean3)
        labels.append(0)
        i=i+8
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
def get_deve_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = json.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
trainDF=get_tweet_from_json("train.json")
devDF=get_deve_from_json("dev.json")
train_x=trainDF['text']
train_y=trainDF['label']
valid_x=devDF['text']
valid_y=devDF['label']