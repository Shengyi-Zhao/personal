'''
parameter of adjustment for random forest
'''
from io import StringIO


import numpy
import openpyxl
import xgboost
from keras.preprocessing import text
from keras_preprocessing import sequence

from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from sklearn import metrics, svm, ensemble
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import pandas, string, more_data
import os
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.model_selection import GridSearchCV


def convert_pdf_2_text(path):

    rsrcmgr = PDFResourceManager()
    retstr = StringIO()

    device = TextConverter(rsrcmgr, retstr, laparams=LAParams())
    interpreter = PDFPageInterpreter(rsrcmgr, device)

    with open(path, 'rb') as fp:
        for page in PDFPage.get_pages(fp, set()):
            interpreter.process_page(page)
        text = retstr.getvalue()

    device.close()
    retstr.close()

    return text


import re
new_text1=convert_pdf_2_text('climate-change-wr.pdf')
pattern = r'\.'
result_list = re.split(pattern, new_text1)
result_list2=[]
f = open("new 1.txt",'rb')
line = f.readline()
while line:
    s=str(line, encoding="utf-8")
    result_list2.append(s)
    line = f.readline()
f.close()
result_list3=[]
f2=open('News_Category_Dataset_v2.json', 'r', encoding="utf-8")
    # 读取所有行 每行会是一个字符串
for str in f2.readlines():
    # 将josn字符串转化为dict字典
    j = more_data.loads(str)
    t = j["headline"]+j["short_description"]
    result_list3.append(t)
f2.close()
result_list4=[]
new_text5=convert_pdf_2_text('new 5.pdf')
pattern2 = r'\...'
result_list5 = re.split(pattern2, new_text5)
new_text6=convert_pdf_2_text('new 6.pdf')
result_list6 = re.split(pattern2, new_text6)

workbook=openpyxl.load_workbook("naturalnews.xlsx")
worksheet=workbook.get_sheet_by_name("data")
name=worksheet.title
columns=worksheet.max_column
for row in worksheet.rows:
    text4=row[0].value+row[1].value
    result_list4.append(text4)


stop = set(stopwords.words('english'))
exclude = set(string.punctuation)
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized


def get_tweet_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    i=0
    while i <(len(result_list)-2):
        text1=result_list[i]
        text2 =result_list[i+1]
        text3 =result_list[i+2]
        new_data_after_clean = clean(text1)+clean(text2)+clean(text3)
        texts.append(new_data_after_clean)
        labels.append(0)
        i=i+3
    i=0
    while i <(len(result_list2)-4):
        text1=result_list2[i]
        text2=result_list2[i+1]
        text3=result_list2[i+2]
        text4=result_list2[i+3]
        text5=result_list2[i+4]
        new_data2=text1+text2+text3+text4+text5
        new_data_after_clean2 = clean(new_data2)
        texts.append(new_data_after_clean2)
        labels.append(0)
        i=i+5
    while i <(len(result_list3)-7):
        text1=result_list3[i]
        text2=result_list3[i+1]
        text3=result_list3[i+2]
        text4=result_list3[i+3]
        text5=result_list3[i+4]
        text6 = result_list3[i + 5]
        text7 = result_list3[i + 6]
        text8 = result_list3[i + 7]
        new_data3=text1+text2+text3+text4+text5+text6+text7+text8
        new_data_after_clean3 = clean(new_data3)
        texts.append(new_data_after_clean3)
        labels.append(0)
        i=i+8
    for t in result_list4:
        texts.append(t)
        labels.append(1)
    for aa in result_list5:
        texts.append(aa)
        labels.append(0)
    for aaa in result_list6:
        texts.append(aaa)
        labels.append(0)
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
def get_deve_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
trainDF=get_tweet_from_json("train.json")
devDF=get_deve_from_json("dev.json")
train_x=trainDF['text']
train_y=trainDF['label']
valid_x=devDF['text']
valid_y=devDF['label']

#创建一个向量计数器对象
count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
count_vect.fit(trainDF['text'])

#使用向量计数器对象转换训练集和验证集
xtrain_count = count_vect.transform(train_x)
xvalid_count = count_vect.transform(valid_x)
# ngram 级tf-idf
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram = tfidf_vect_ngram.transform(train_x)
xvalid_tfidf_ngram = tfidf_vect_ngram.transform(valid_x)


def train_model(classifier, feature_vector_train, label, feature_vector_valid, is_neural_net=False):
    # fit the training dataset on the classifier
    classifier.fit(feature_vector_train, label)

    # predict the labels on validation dataset
    predictions = classifier.predict(feature_vector_valid)

    if is_neural_net:
        predictions = predictions.argmax(axis=-1)
    j=0
    for i in range(len(predictions)):
        if valid_y[i] != predictions[i]:
            print(valid_x[i])
            print(valid_y[i])
            print(predictions[i])
            j=j+1
            print(j)
            print('----------')
    print(j)
    print(len(predictions))

    return metrics.accuracy_score(predictions, valid_y)



    return model
#加载预先训练好的词嵌入向量
embeddings_index = {}
for i, line in enumerate(open('E:\wiki-news-300d-1M.vec',encoding='utf-8')):
    values = line.split()
    embeddings_index[values[0]] = numpy.asarray(values[1:], dtype='float32')


#创建一个分词器
token = text.Tokenizer()
token.fit_on_texts(trainDF['text'])
word_index = token.word_index

#将文本转换为分词序列，并填充它们保证得到相同长度的向量
train_seq_x = sequence.pad_sequences(token.texts_to_sequences(train_x), maxlen=70)
valid_seq_x = sequence.pad_sequences(token.texts_to_sequences(valid_x), maxlen=70)

#创建分词嵌入映射
embedding_matrix = numpy.zeros((len(word_index) + 1, 300))
for word, i in word_index.items():
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None:
        embedding_matrix[i] = embedding_vector




depth_set=[None,50,70,90,110,130,150,170,190]
sample_set= [2,3,5,7,9,11,13]
weight_set=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9,10]
estimators_set=[10,20,30,40,50,60,70,100]
leaf_set=[1,10,20,30,40,50]
feature_set=[3,5,7,9,'auto']






'''
for e in estimators_set:
        for i in weight_set:
            clf = ensemble.RandomForestClassifier(n_estimators=e,class_weight={1: 1, 0: i},)
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(e,' ',i)
            print(metrics.f1_score(y_pred_test, valid_y))
        clf = ensemble.RandomForestClassifier(n_estimators=e)
        clf.fit(xtrain_tfidf_ngram, train_y)
        y_pred_test = clf.predict(xvalid_tfidf_ngram)
        for index in range(len(y_pred_test)):
            if y_pred_test[index] == -1:
                y_pred_test[index] = 0
        print(e,' n')
        print(metrics.f1_score(y_pred_test, valid_y))
for i in weight_set:
    clf = ensemble.RandomForestClassifier( class_weight={1: 1, 0: i})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print('n ', i)
    print(metrics.f1_score(y_pred_test, valid_y))
clf = ensemble.RandomForestClassifier()
clf.fit(xtrain_tfidf_ngram, train_y)
y_pred_test = clf.predict(xvalid_tfidf_ngram)
for index in range(len(y_pred_test)):
    if y_pred_test[index] == -1:
        y_pred_test[index] = 0
print('n n')
print(metrics.f1_score(y_pred_test, valid_y))
'''


'''
for d in depth_set:
    for s in sample_set:
            clf = ensemble.RandomForestClassifier(max_depth=d,min_samples_split=s,n_estimators=10,class_weight={1: 1, 0: 9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(d,' ',s,'10,9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(max_depth=d, min_samples_split=s, n_estimators=70,class_weight={1: 1, 0: 5})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(d, ' ', s, '70,5')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(max_depth=d, min_samples_split=s, n_estimators=30,class_weight={1: 1, 0: 0.9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(d, ' ', s, '30,0.9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(max_depth=d, min_samples_split=s, n_estimators=50,class_weight={1: 1, 0:0.2})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(d, ' ', s, '50,0.2')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(max_depth=d, min_samples_split=s, n_estimators=50,class_weight={1: 1, 0: 0.9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(d, ' ', s, '50,0.9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(max_depth=d, min_samples_split=s, n_estimators=60,class_weight={1: 1, 0: 0.8})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(d, ' ', s, '60,0.8')
            print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(max_depth=d,  n_estimators=10, class_weight={1: 1, 0: 9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(d, ' n', '10,9')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(max_depth=d,  n_estimators=70, class_weight={1: 1, 0: 5})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(d, ' n', '70,5')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(max_depth=d,  n_estimators=30,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(d, ' n', '30,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(max_depth=d,  n_estimators=50,
                                          class_weight={1: 1, 0: 0.2})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(d, ' n', '50,0.2')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(max_depth=d,  n_estimators=50,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(d, ' n', '50,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(max_depth=d,  n_estimators=60,
                                          class_weight={1: 1, 0: 0.8})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(d, ' ', s, '60,0.8')
    print(metrics.f1_score(y_pred_test, valid_y))
for s in sample_set:
            clf = ensemble.RandomForestClassifier(min_samples_split=s,n_estimators=10,class_weight={1: 1, 0: 9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print('n ',s,'10,9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier( min_samples_split=s, n_estimators=70,class_weight={1: 1, 0: 5})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print('n ', s, '70,5')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier( min_samples_split=s, n_estimators=30,class_weight={1: 1, 0: 0.9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print('n ', s, '30,0.9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier( min_samples_split=s, n_estimators=50,class_weight={1: 1, 0:0.2})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print('n ', s, '50,0.2')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier( min_samples_split=s, n_estimators=50,class_weight={1: 1, 0: 0.9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print('n ', s, '50,0.9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier( min_samples_split=s, n_estimators=60,class_weight={1: 1, 0: 0.8})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print('n ', s, '60,0.8')
            print(metrics.f1_score(y_pred_test, valid_y))
'''











'''
for l in leaf_set:
    for s in sample_set:
            clf = ensemble.RandomForestClassifier(min_samples_leaf=l,min_samples_split=s,n_estimators=60,class_weight={1: 1, 0: 0.8})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(l,' ',s,'n,60,0.8')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(min_samples_leaf=l,min_samples_split=s,n_estimators=50,class_weight={1: 1, 0: 0.9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(l,' ',s,'n,50,0.9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(min_samples_leaf=l,min_samples_split=s,max_depth=190,n_estimators=60,class_weight={1: 1, 0: 0.8})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(l,' ',s,'190,60,0.8')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(min_samples_leaf=l,min_samples_split=s,max_depth=170,n_estimators=60,class_weight={1: 1, 0: 0.8})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(l,' ',s,'170,60,0.8')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(min_samples_leaf=l,min_samples_split=s,max_depth=90,n_estimators=50,class_weight={1: 1, 0: 0.9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(l,' ',s,'90,50,0.9')
            print(metrics.f1_score(y_pred_test, valid_y))
            clf = ensemble.RandomForestClassifier(min_samples_leaf=l,min_samples_split=s,max_depth=130,n_estimators=50,class_weight={1: 1, 0: 0.9})
            clf.fit(xtrain_tfidf_ngram, train_y)
            y_pred_test = clf.predict(xvalid_tfidf_ngram)
            for index in range(len(y_pred_test)):
                if y_pred_test[index] == -1:
                    y_pred_test[index] = 0
            print(l,' ',s,'130,50,0.9')
            print(metrics.f1_score(y_pred_test, valid_y))

    clf = ensemble.RandomForestClassifier(min_samples_leaf=l, n_estimators=60,
                                          class_weight={1: 1, 0: 0.8})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(l, ' n', 'n,60,0.8')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(min_samples_leaf=l, n_estimators=50,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(l, ' n', 'n,50,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(min_samples_leaf=l, max_depth=190, n_estimators=60,
                                          class_weight={1: 1, 0: 0.8})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(l, ' n', '190,60,0.8')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(min_samples_leaf=l, max_depth=170, n_estimators=60,
                                          class_weight={1: 1, 0: 0.8})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(l, ' n',  '170,60,0.8')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(min_samples_leaf=l, max_depth=90, n_estimators=50,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(l, ' n', '90,50,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(min_samples_leaf=l,  max_depth=130, n_estimators=50,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(l, ' n',  '130,50,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))
'''





'''
for s in sample_set:
    clf = ensemble.RandomForestClassifier( min_samples_split=s, n_estimators=60,
                                          class_weight={1: 1, 0: 0.8})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print( 'l ', s, 'n,60,0.8')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier( min_samples_split=s, n_estimators=50,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print( 'l ', s, 'n,50,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier(min_samples_split=s, max_depth=190, n_estimators=60,
                                          class_weight={1: 1, 0: 0.8})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print('l ', s, '190,60,0.8')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier( min_samples_split=s, max_depth=170, n_estimators=60,
                                          class_weight={1: 1, 0: 0.8})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print( 'l ', s, '170,60,0.8')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier( min_samples_split=s, max_depth=90, n_estimators=50,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print('l ', s, '90,50,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))
    clf = ensemble.RandomForestClassifier( min_samples_split=s, max_depth=130, n_estimators=50,
                                          class_weight={1: 1, 0: 0.9})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print('l ', s, '130,50,0.9')
    print(metrics.f1_score(y_pred_test, valid_y))

'''

'''
for e in estimators_set:
    for d in depth_set:
        for s in sample_set:
            for l in leaf_set:
                for i in weight_set:
                    clf = ensemble.RandomForestClassifier(min_samples_leaf=l, max_depth=d, n_estimators=e,
                                                          min_samples_split=s,
                                                          class_weight={1: 1, 0: i})
                    clf.fit(xtrain_tfidf_ngram, train_y)
                    y_pred_test = clf.predict(xvalid_tfidf_ngram)
                    for index in range(len(y_pred_test)):
                        if y_pred_test[index] == -1:
                            y_pred_test[index] = 0
                    if metrics.f1_score(y_pred_test, valid_y) > 0.82:
                        print(e, ' ', d, ' ', s, ' ', l, ' n')
                        print(metrics.f1_score(y_pred_test, valid_y))
                clf = ensemble.RandomForestClassifier(min_samples_leaf=l, max_depth=d, n_estimators=e,
                                                      min_samples_split=s,)
                clf.fit(xtrain_tfidf_ngram, train_y)
                y_pred_test = clf.predict(xvalid_tfidf_ngram)
                for index in range(len(y_pred_test)):
                    if y_pred_test[index] == -1:
                        y_pred_test[index] = 0
                if metrics.f1_score(y_pred_test, valid_y)>0.82:
                    print(e, ' ', d, ' ', s, ' ', l, ' n')
                    print(metrics.f1_score(y_pred_test, valid_y))

'''




for i in weight_set:
    clf = ensemble.RandomForestClassifier(min_samples_leaf=1, max_depth=190, n_estimators=10,
                                          min_samples_split=7,
                                          class_weight={1: 1, 0: i})
    clf.fit(xtrain_tfidf_ngram, train_y)
    y_pred_test = clf.predict(xvalid_tfidf_ngram)
    for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0
    print(i)
    print(metrics.f1_score(y_pred_test, valid_y),' ',metrics.recall_score(y_pred_test, valid_y))
clf = ensemble.RandomForestClassifier(min_samples_leaf=1,  max_depth=190,n_estimators=10,
                                          min_samples_split=7)
clf.fit(xtrain_tfidf_ngram, train_y)
y_pred_test = clf.predict(xvalid_tfidf_ngram)
for index in range(len(y_pred_test)):
        if y_pred_test[index] == -1:
            y_pred_test[index] = 0

print(metrics.f1_score(y_pred_test, valid_y),' ',metrics.recall_score(y_pred_test, valid_y))








'''
rf0 = RandomForestClassifier(oob_score=True, random_state=10)
rf0.fit(xtrain_tfidf_ngram,train_y)
param_test1= {'n_estimators':range(10,71,10)}
gsearch1= GridSearchCV(estimator = RandomForestClassifier(min_samples_split=100,
                                 min_samples_leaf=20,max_depth=8,max_features='sqrt' ,random_state=10),
                       param_grid =param_test1, scoring='roc_auc',cv=5)
gsearch1.fit(xtrain_tfidf_ngram,train_y)
print(gsearch1.best_params_, gsearch1.best_score_)
param_test2= {'max_depth':range(3,14,2), 'min_samples_split':range(50,201,20)}
gsearch2= GridSearchCV(estimator = RandomForestClassifier(n_estimators= 70,
                                 min_samples_leaf=20,max_features='sqrt' ,oob_score=True,random_state=10),
   param_grid = param_test2,scoring='roc_auc',iid=False, cv=5)
param_test3= {'min_samples_split':range(60,200,20), 'min_samples_leaf':range(10,60,10)}
gsearch3= GridSearchCV(estimator = RandomForestClassifier(n_estimators= 70,max_depth=13,
                                 max_features='sqrt' ,oob_score=True, random_state=10),
   param_grid = param_test3,scoring='roc_auc',iid=False, cv=5)
param_test4= {'max_features':range(3,11,2)}
gsearch4= GridSearchCV(estimator = RandomForestClassifier(n_estimators= 70,max_depth=13, min_samples_split=120,
                                 min_samples_leaf=10 ,oob_score=True, random_state=10),
   param_grid = param_test4,scoring='roc_auc',iid=False, cv=5)



gsearch4.fit(xtrain_tfidf_ngram,train_y)
print(gsearch4.best_params_, gsearch4.best_score_)

rf0 = RandomForestClassifier(oob_score=True, random_state=10)
rf0.fit(xtrain_tfidf_ngram,train_y)
x=[{1: 1, 0: 0.1},{1: 1, 0: 0.2},{1: 1, 0: 0.3},{1: 1, 0: 0.4},{1: 1, 0: 0.5},{1: 1, 0: 0.6},{1: 1, 0: 0.7},{1: 1, 0: 0.8}
    ,{1: 1, 0: 0.9},{1: 1, 0: 1},{1: 1, 0: 2},{1: 1, 0: 3},{1: 1, 0: 4},{1: 1, 0: 5},{1: 1, 0: 6},{1: 1, 0: 7},{1: 1, 0: 8}
,{1: 1, 0: 9},{1: 1, 0: 10},None]
param_test5= {'class_weight':x}
gsearch5= GridSearchCV(estimator = RandomForestClassifier(n_estimators= 70,max_depth=13, min_samples_split=120,
                                 min_samples_leaf=10 ,oob_score=True, random_state=10,max_features=10),
   param_grid = param_test5,scoring='roc_auc',iid=False, cv=5)



gsearch5.fit(xtrain_tfidf_ngram,train_y)
print(gsearch5.best_params_, gsearch5.best_score_)
'''