
import token
from io import StringIO
import matplotlib.pyplot as plt
from sklearn.metrics import auc, roc_curve
import numpy
import xgboost
from keras_preprocessing import sequence, text
from nltk.corpus import stopwords
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from sklearn import metrics, svm, ensemble
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import pandas, string, more_data
import os
from nltk import WordNetLemmatizer
from keras import layers, models, optimizers
from sklearn.model_selection import GridSearchCV


def convert_pdf_2_text(path):

    rsrcmgr = PDFResourceManager()
    retstr = StringIO()

    device = TextConverter(rsrcmgr, retstr, laparams=LAParams())
    interpreter = PDFPageInterpreter(rsrcmgr, device)

    with open(path,'rb') as fp:
        for page in PDFPage.get_pages(fp, set()):
            interpreter.process_page(page)
        text = retstr.getvalue()

    device.close()
    retstr.close()

    return text


import re

new_text1=convert_pdf_2_text('climate-change-wr.pdf')
pattern = r'\.'
result_list = re.split(pattern, new_text1)
result_list2=[]
f = open("new 1.txt",'rb')
line = f.readline()
while line:
    s=str(line, encoding="utf-8")
    result_list2.append(s)
    line = f.readline()
f.close()
result_list3=[]
f2=open('News_Category_Dataset_v2.json', 'r', encoding="utf-8")
    # 读取所有行 每行会是一个字符串
for str in f2.readlines():
    # 将josn字符串转化为dict字典
    j = more_data.loads(str)
    t = j["headline"]+j["short_description"]
    result_list3.append(t)
f2.close()

stop = set(stopwords.words('english'))
exclude = set(string.punctuation)
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized


def get_tweet_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    i=0
    while i <(len(result_list)-2):
        text1=result_list[i]
        text2 =result_list[i+1]
        text3 =result_list[i+2]
        new_data_after_clean = clean(text1)+clean(text2)+clean(text3)
        texts.append(new_data_after_clean)
        labels.append(0)
        i=i+3
    i=0
    while i <(len(result_list2)-4):
        text1=result_list2[i]
        text2=result_list2[i+1]
        text3=result_list2[i+2]
        text4=result_list2[i+3]
        text5=result_list2[i+4]
        new_data2=text1+text2+text3+text4+text5
        new_data_after_clean2 = clean(new_data2)
        texts.append(new_data_after_clean2)
        labels.append(0)
        i=i+5
    while i <(len(result_list3)-7):
        text1=result_list3[i]
        text2=result_list3[i+1]
        text3=result_list3[i+2]
        text4=result_list3[i+3]
        text5=result_list3[i+4]
        text6 = result_list3[i + 5]
        text7 = result_list3[i + 6]
        text8 = result_list3[i + 7]
        new_data3=text1+text2+text3+text4+text5+text6+text7+text8
        new_data_after_clean3 = clean(new_data3)
        texts.append(new_data_after_clean3)
        labels.append(0)
        i=i+8
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
def get_deve_from_json(file_name):
    labels, texts = [], []
    bait_type_path = os.path.dirname(__file__)
    json_file = os.path.join(bait_type_path, file_name)
    with open(json_file) as f:
        data = more_data.load(f)  # js是转换后的字典
    for value in data:
        infor = data[value]
        text_afterclean = clean(infor['text'])
        texts.append(text_afterclean)
        labels.append(infor['label'])
    DF = pandas.DataFrame()
    DF['text'] = texts
    DF['label'] = labels
    return DF
trainDF=get_tweet_from_json("train.json")
devDF=get_deve_from_json("dev.json")
train_x=trainDF['text']
train_y=trainDF['label']
valid_x=devDF['text']
valid_y=devDF['label']

#创建一个向量计数器对象
count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
count_vect.fit(trainDF['text'])

#使用向量计数器对象转换训练集和验证集
xtrain_count = count_vect.transform(train_x)
xvalid_count = count_vect.transform(valid_x)
# ngram 级tf-idf
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram = tfidf_vect_ngram.transform(train_x)
xvalid_tfidf_ngram = tfidf_vect_ngram.transform(valid_x)


def train_model(classifier, feature_vector_train, label, feature_vector_valid, is_neural_net=False):
    # fit the training dataset on the classifier
    classifier.fit(feature_vector_train, label)

    # predict the labels on validation dataset
    predictions = classifier.predict(feature_vector_valid)

    if is_neural_net:
        predictions = predictions.argmax(axis=-1)
    j=0
    for i in range(len(predictions)):
        if valid_y[i] != predictions[i]:
            print(valid_x[i])
            print(valid_y[i])
            print(predictions[i])
            j=j+1
            print(j)
            print('----------')
    print(j)
    print(len(predictions))

    return metrics.accuracy_score(predictions, valid_y)

def create_cnn():
    # Add an Input Layer
    input_layer = layers.Input((70,))

    # Add the word embedding Layer
    embedding_layer = layers.Embedding(len(word_index) + 1, 300, weights=[embedding_matrix], trainable=False)(
        input_layer)
    embedding_layer = layers.SpatialDropout1D(0.3)(embedding_layer)

    # Add the convolutional Layer
    conv_layer = layers.Convolution1D(100, 3, activation="relu")(embedding_layer)

    # Add the pooling Layer
    pooling_layer = layers.GlobalMaxPool1D()(conv_layer)

    # Add the output Layers
    output_layer1 = layers.Dense(50, activation="relu")(pooling_layer)
    output_layer1 = layers.Dropout(0.25)(output_layer1)
    output_layer2 = layers.Dense(1, activation="sigmoid")(output_layer1)

    # Compile the model
    model = models.Model(inputs=input_layer, outputs=output_layer2)
    model.compile(optimizer=optimizers.Adam(), loss='binary_crossentropy')

    return model
#加载预先训练好的词嵌入向量
embeddings_index = {}
for i, line in enumerate(open('E:\wiki-news-300d-1M.vec',encoding='utf-8')):
    values = line.split()
    embeddings_index[values[0]] = numpy.asarray(values[1:], dtype='float32')


#创建一个分词器
token = text.Tokenizer()
token.fit_on_texts(trainDF['text'])
word_index = token.word_index

#将文本转换为分词序列，并填充它们保证得到相同长度的向量
train_seq_x = sequence.pad_sequences(token.texts_to_sequences(train_x), maxlen=70)
valid_seq_x = sequence.pad_sequences(token.texts_to_sequences(valid_x), maxlen=70)

#创建分词嵌入映射
embedding_matrix = numpy.zeros((len(word_index) + 1, 300))
for word, i in word_index.items():
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None:
        embedding_matrix[i] = embedding_vector










clf = ensemble.RandomForestClassifier(min_samples_leaf=1, max_depth=190 ,n_estimators=30,
                                          min_samples_split=2,
                                          class_weight={1: 1, 0: 3})
clf.fit(xtrain_tfidf_ngram, train_y)
y_pred_test = clf.predict(xvalid_tfidf_ngram)
for index in range(len(y_pred_test)):
    if y_pred_test[index] == -1:
            y_pred_test[index] = 0

print(metrics.f1_score(y_pred_test, valid_y),metrics.precision_score(y_pred_test, valid_y),metrics.recall_score(y_pred_test, valid_y))





'''
fpr, tpr, thresholds_keras = roc_curve(y_pred_test,valid_y)




auc =auc(fpr, tpr)
print("AUC : ", auc)
plt.figure()
plt.plot([0, 1], [0, 1], 'k--')
plt.plot(fpr, tpr, label='Keras (area = {:.3f})'.format(auc))
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')
plt.title('ROC curve')
plt.legend(loc='best')
plt.savefig("1.png")
plt.show()

'''





