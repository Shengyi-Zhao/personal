'''
COMP90024 
group 23
969048 Zhaoying Chen
960423 Yukun Bo
990294 Yuanyuan Wang
990160 Shengyi Zhao
683880 Stephanie Zi Xin Ng
'''


from flask import Flask, render_template, url_for
import couchdb

app = Flask(__name__,
	static_url_path='',
	static_folder = 'static')

couchdb_url = 'http://admin:admin@172.26.132.84:5984/'
#couchdb_url = 'http://admin:admin@172.26.130.112:5984/'
#couchdb_url = 'http://admin:admin@172.26.130.153:5984/'
server = couchdb.Server(couchdb_url)

db = server['all_db']
db_aurin = server['aurin_db']

@app.route('/')
def index():
    return render_template('admin.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/Overview')
def Overview():
    return render_template('Overview.html')

@app.route('/Time')
def Time():
    return render_template('Time.html')

@app.route('/Sentiment')
def Sentiment():
    return render_template('Sentiment.html')

@app.route('/Covid')
def Covid():
    return render_template('Covid-19.html')

@app.route('/Food')
def Food():
    return render_template('Food.html')

@app.route('/map')
def map():
    return render_template('map.html')


import api.web_fun
